import requests
import xlwt
from bs4 import BeautifulSoup

def getHTMLText(url):
    try:
        r = requests.get(url)
        r.raise_for_status()
        r.encoding = 'gbk'
        return r.text
    except:
        return ""

def getPCList(url):
    PC_name_list = []
    PC_conf_list = []
    PC_link_list = []
    html = getHTMLText(url)
    soup = BeautifulSoup(html,'html.parser')
    mark_ul = soup.find_all(
        'ul', {'class': 'list-items list-type-tw clearfix', 'id': 'JlistItems'})
    mark_div = mark_ul[0].find_all('div', {'class': 'item-pic'})
    for div in mark_div:
        mark_img = div.find('img',{'class':'pic'})
        PC_name = mark_img.get('alt')
        PC_name_list.append(PC_name)
        PC_conf = mark_img.get('title')
        PC_conf_list.append(PC_conf)
        mark_a = div.find('a',{})
        PC_link = mark_a.get('href')
        PC_link_list.append(PC_link)
    return PC_name_list, PC_conf_list, PC_link_list

def set_style(name, height, bold=False):
    style = xlwt.XFStyle()  # 初始化样式

    font = xlwt.Font()  # 为样式创建字体
    font.name = name  # 'Times New Roman'
    font.bold = bold
    font.color_index = 4
    font.height = height
    style.font = font
    return style

def write_excel(PC_name_list, PC_conf_list, PC_link_list):
    f = xlwt.Workbook()  # 创建工作簿

    ''''' 
    创建第一个sheet: 
    sheet1 
    '''
    sheet1 = f.add_sheet(u'sheet1', cell_overwrite_ok=True)  # 创建sheet
    row0 = [u'电脑型号', u'电脑配置', u'购买链接']
    first_col = sheet1.col(0)
    second_col = sheet1.col(1)
    third_col = sheet1.col(2)
    first_col.width = 256*40
    second_col.width = 256*40
    third_col.width = 256*60
    style1 = set_style('Times New Roman', 280, True)
    style2 = set_style('Times New Roman', 220)
    #生成第一行
    for i in range(0, len(row0)):
        sheet1.write(0, i, row0[i], style1)
    for i in range(0, len(PC_name_list)):
        sheet1.write(i+1, 0, PC_name_list[i], style2)
    for i in range(0, len(PC_conf_list)):
        sheet1.write(i+1, 1, PC_conf_list[i], style2)
    for i in range(0, len(PC_link_list)):
        sheet1.write(i+1, 2, PC_link_list[i], style2)
    f.save('PC_data.xlsx')  # 保存文件

if __name__ == "__main__":
    url_beg = 'http://product.pconline.com.cn/notebook/'
    url_end = 's10.shtml'
    url2_beg = 'http://product.pconline.com.cn/notebook/msi/'
    url2_end = 's1.shtml'
    PC_temp_name_list = []
    PC_temp_conf_list = []
    PC_temp_link_list = []
    PC_name_list = []
    PC_conf_list = []
    PC_link_list = []
    for i in range(398):
        url = url_beg + str(25*i) + url_end
        print(url)
        PC_temp_name_list, PC_temp_conf_list, PC_temp_link_list = getPCList(url)
        PC_name_list += PC_temp_name_list
        PC_conf_list += PC_temp_conf_list
        PC_link_list += PC_temp_link_list
    for i in range(5):
        url = url2_beg + str(25*i) + url2_end
        print(url)
        PC_temp_name_list, PC_temp_conf_list, PC_temp_link_list = getPCList(url)
        PC_name_list += PC_temp_name_list
        PC_conf_list += PC_temp_conf_list
        PC_link_list += PC_temp_link_list
    write_excel(PC_name_list, PC_conf_list, PC_link_list)
